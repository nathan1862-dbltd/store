<?php
require_once __DIR__ . '/adminconfig.php';

if (!isset($_SESSION[ADMIN_SESSION_KEY])) {
    header("Location: " . ADMIN_LOGIN_PAGE);
    exit;
}
