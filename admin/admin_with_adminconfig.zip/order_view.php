<?php
ini_set('display_errors',1);
error_reporting(E_ALL);

require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/../functions.php';
requireAdmin();

$orderId = (int)($_GET['id'] ?? 0);
if (!$orderId) die("Invalid order");

$stmt = $mysqli->prepare("
    SELECT 
        id,
        user_id,
        name,
        phone,
        address,
        subtotal,
        shipping_fee,
        discount,
        total,
        payment_method,
        payment_status,
        status,
        created_at
    FROM orders
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) die("Order not found");

/* SAFE NUMBERS */
$subtotal = (float)($order['subtotal'] ?? 0);
$discount = (float)($order['discount'] ?? 0);
$shipping = (float)($order['shipping_fee'] ?? 0);
$total    = (float)($order['total'] ?? 0);

/* ===============================
   UPDATE STATUS
================================ */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $newStatus = $_POST['status'] ?? '';
    $allowed = ['pending','processing','shipped','delivered','cancelled'];

    if (!in_array($newStatus,$allowed)) {
        die("Invalid status");
    }

    $stmt = $mysqli->prepare("
        UPDATE orders
        SET status = ?
        WHERE id = ?
    ");
    $stmt->bind_param("si", $newStatus, $orderId);
    $stmt->execute();
    $stmt->close();

    /* LOYALTY ADD WHEN DELIVERED */
    if ($newStatus === 'delivered') {

        $check = $mysqli->prepare("
            SELECT id FROM loyalty_ledger
            WHERE order_id = ? AND type='earn'
            LIMIT 1
        ");
        $check->bind_param("i", $orderId);
        $check->execute();
        $exists = $check->get_result()->fetch_assoc();
        $check->close();

        if (!$exists) {

            $points = floor($total / 1000);
            $expires = date('Y-m-d H:i:s', strtotime('+6 months'));

            $stmt = $mysqli->prepare("
                INSERT INTO loyalty_ledger
                (user_id, order_id, points, type, status, expires_at)
                VALUES (?, ?, ?, 'earn', 'approved', ?)
            ");

            $stmt->bind_param(
                "iiis",
                $order['user_id'],
                $orderId,
                $points,
                $expires
            );

            $stmt->execute();
            $stmt->close();
        }
    }

    header("Location: order_view.php?id=".$orderId);
    exit;
}

/* FETCH ITEMS */
$stmt = $mysqli->prepare("
    SELECT product_name, variant_name, quantity, unit_price
    FROM order_items
    WHERE order_id = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$items = $stmt->get_result();
$stmt->close();
?>

<h2>Order #<?= $order['id'] ?></h2>

<p><strong>Customer:</strong> <?= htmlspecialchars($order['name'] ?? 'N/A') ?></p>
<p><strong>Phone:</strong> <?= htmlspecialchars($order['phone'] ?? 'N/A') ?></p>
<p><strong>Address:</strong> <?= nl2br(htmlspecialchars($order['address'] ?? 'N/A')) ?></p>

<p><strong>Status:</strong> <?= ucfirst($order['status'] ?? 'pending') ?></p>
<p><strong>Payment Method:</strong> <?= ucfirst($order['payment_method'] ?? 'cod') ?></p>
<p><strong>Payment Status:</strong> <?= ucfirst($order['payment_status'] ?? 'unpaid') ?></p>
<p><strong>Date:</strong> <?= date("d M Y H:i", strtotime($order['created_at'])) ?></p>

<form method="post">
<select name="status">
<?php foreach(['pending','processing','shipped','delivered','cancelled'] as $s): ?>
<option value="<?= $s ?>" <?= ($order['status']===$s?'selected':'') ?>>
<?= ucfirst($s) ?>
</option>
<?php endforeach; ?>
</select>
<button type="submit">Update</button>
</form>

<hr>

<h3>Order Items</h3>

<table border="1" cellpadding="8" width="100%">
<tr>
    <th>Product</th>
    <th>Variant</th>
    <th>Qty</th>
    <th>Unit Price</th>
    <th>Total</th>
</tr>

<?php while($i = $items->fetch_assoc()):
$line = $i['quantity'] * $i['unit_price'];
?>
<tr>
    <td><?= htmlspecialchars($i['product_name']) ?></td>
    <td><?= htmlspecialchars($i['variant_name']) ?></td>
    <td><?= $i['quantity'] ?></td>
    <td><?= number_format($i['unit_price'],2) ?></td>
    <td><?= number_format($line,2) ?></td>
</tr>
<?php endwhile; ?>
</table>

<br>

<p><strong>Subtotal:</strong> <?= number_format($subtotal,2) ?></p>
<p><strong>Discount:</strong> -<?= number_format($discount,2) ?></p>
<p><strong>Shipping:</strong> <?= number_format($shipping,2) ?></p>
<p><strong>Grand Total:</strong> <?= number_format($total,2) ?></p>