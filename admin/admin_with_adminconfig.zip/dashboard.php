<?php require_once 'admin_auth.php'; ?>
<!doctype html>
<html>
<head>
<title>Admin Dashboard</title>
</head>
<body>
<h2>Admin Dashboard</h2>
<ul>
<li><a href="products.php">Products</a></li>
<li><a href="orders.php">Orders</a></li>
<li><a href="points.php">Points</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>
</body>
</html>