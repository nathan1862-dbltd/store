<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/admin_header.php';

/* ================= SLUG ================= */

function createSlug($string) {
    $slug = strtolower(trim($string));
    $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
    $slug = trim($slug, '-');
    return $slug;
}

function generateUniqueSlug($mysqli, $baseSlug) {
    $slug = $baseSlug;
    $counter = 1;

    while (true) {
        $stmt = $mysqli->prepare("SELECT id FROM products WHERE slug=? LIMIT 1");
        $stmt->bind_param("s", $slug);
        $stmt->execute();

        if ($stmt->get_result()->num_rows === 0) {
            return $slug;
        }

        $slug = $baseSlug . '-' . $counter;
        $counter++;
    }
}

/* ================= IMAGE UPLOAD ================= */

function uploadImage($file, $subdir = 'products') {
    if (empty($file['name'])) return null;
    if (!is_uploaded_file($file['tmp_name'])) return null;

    $baseDir = __DIR__ . '/../uploads/' . $subdir . '/';
    if (!is_dir($baseDir)) mkdir($baseDir, 0777, true);

    $safeName = preg_replace('/[^a-zA-Z0-9\._-]/', '_', basename($file['name']));
    $finalName = time() . '_' . $safeName;

    if (move_uploaded_file($file['tmp_name'], $baseDir . $finalName)) {
        return 'uploads/' . $subdir . '/' . $finalName;
    }
    return null;
}

/* ================= LOAD DATA ================= */

$brands = $mysqli->query("SELECT id, name FROM brands ORDER BY name ASC");
$cats   = $mysqli->query("SELECT id, name FROM categories ORDER BY name ASC");
$highlights = $mysqli->query("SELECT id, title, svg_icon FROM highlights ORDER BY title ASC");

/* ================= HANDLE FORM ================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $mysqli->begin_transaction();

    try {

        $img1 = uploadImage($_FILES['image1'] ?? []);
        $img2 = uploadImage($_FILES['image2'] ?? []);
        $img3 = uploadImage($_FILES['image3'] ?? []);

        /* INSERT PRODUCT */
        $baseSlug = createSlug($_POST['name']);
        $slug = generateUniqueSlug($mysqli, $baseSlug);

        $stmt = $mysqli->prepare("
            INSERT INTO products 
            (name, slug, description, ingredients, how_to_use, brand_id, image_path, image_path2, image_path3)
            VALUES (?,?,?,?,?,?,?,?,?)
        ");

        $stmt->bind_param(
            "ssssissss",
            $_POST['name'],
            $slug,
            $_POST['description'],
            $_POST['ingredients'],
            $_POST['how_to_use'],
            $_POST['brand_id'],
            $img1,
            $img2,
            $img3
        );

        $stmt->execute();
        $productId = $stmt->insert_id;
        $stmt->close();


        /* INSERT CATEGORIES */
        if (!empty($_POST['categories'])) {
            $pc = $mysqli->prepare("
                INSERT INTO product_categories (product_id, category_id)
                VALUES (?,?)
            ");
            foreach ($_POST['categories'] as $cid) {
                $cid = (int)$cid;
                $pc->bind_param("ii", $productId, $cid);
                $pc->execute();
            }
            $pc->close();
        }

        /* INSERT HIGHLIGHTS (max 6) */
        if (!empty($_POST['highlights'])) {
            $selected = array_slice($_POST['highlights'], 0, 6);

            $ph = $mysqli->prepare("
                INSERT INTO product_highlights (product_id, icon_id)
                VALUES (?, ?)
            ");

            foreach ($selected as $hid) {
                $hid = (int)$hid;
                $ph->bind_param("ii", $productId, $hid);
                $ph->execute();
            }
            $ph->close();
        }

        /* INSERT VARIANTS */
        if (!empty($_POST['variant_name'])) {

            foreach ($_POST['variant_name'] as $i => $variant_name) {

                if (empty($variant_name)) continue;

                $price = (int)$_POST['price'][$i];
                $discount = (int)$_POST['discount_price'][$i];
                $stock = (int)$_POST['stock'][$i];

                $on_sale = ($discount > 0 && $discount < $price) ? 1 : 0;

                $stmt = $mysqli->prepare("
                    INSERT INTO product_variants
                    (product_id, variant_name, price, discount_price, stock, on_sale)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                $stmt->bind_param(
                    "isiiii",
                    $productId,
                    $variant_name,
                    $price,
                    $discount,
                    $stock,
                    $on_sale
                );

                $stmt->execute();
                $stmt->close();
            }
        }

        /* UPDATE has_variant FLAG */
        $countStmt = $mysqli->prepare("
            SELECT COUNT(*) as total FROM product_variants WHERE product_id=?
        ");
        $countStmt->bind_param("i", $productId);
        $countStmt->execute();
        $count = $countStmt->get_result()->fetch_assoc()['total'];

        $hasVariant = ($count > 0) ? 1 : 0;

        $update = $mysqli->prepare("
            UPDATE products SET has_variants=? WHERE id=?
        ");
        $update->bind_param("ii", $hasVariant, $productId);
        $update->execute();

        $mysqli->commit();

        header("Location: products.php");
        exit;

    } catch (Exception $e) {
        $mysqli->rollback();
        echo "<div class='alert alert-danger'>Error: " . $e->getMessage() . "</div>";
    }
}
?>

<div class="topbar">
  <div class="title">Add Product</div>
  <a class="btn-link" href="products.php">← Back</a>
</div>

<div class="card">
<form method="post" enctype="multipart/form-data">

<div class="form-row">
  <input name="name" placeholder="Product name" required style="flex:1">
  <select name="brand_id" required>
    <option value="">Select brand</option>
    <?php while($b=$brands->fetch_assoc()): ?>
      <option value="<?= (int)$b['id'] ?>"><?= htmlspecialchars($b['name']) ?></option>
    <?php endwhile; ?>
  </select>
</div>

<textarea name="description" placeholder="Description"></textarea>
<textarea name="ingredients" placeholder="Ingredients"></textarea>
<textarea name="how_to_use" placeholder="How to use"></textarea>

<hr>

<strong>Categories</strong><br>
<?php while($c=$cats->fetch_assoc()): ?>
<label>
  <input type="checkbox" name="categories[]" value="<?= (int)$c['id'] ?>">
  <?= htmlspecialchars($c['name']) ?>
</label>
<?php endwhile; ?>

<hr>

<strong>Highlights (max 6)</strong><br>
<?php while($h=$highlights->fetch_assoc()): ?>
<label>
  <input type="checkbox" class="hlCheck" name="highlights[]" value="<?= (int)$h['id'] ?>">
  <?= htmlspecialchars($h['title']) ?>
</label>
<?php endwhile; ?>

<hr>

<strong>Images</strong><br>
<input type="file" name="image1"><br>
<input type="file" name="image2"><br>
<input type="file" name="image3"><br>

<hr>

<h4>Variants</h4>

<div id="variant-container">
  <div class="variant-row">
    <input name="variant_name[]" placeholder="Size (e.g. 30ml)" required>
    <input name="price[]" type="number" placeholder="Price" required>
    <input name="discount_price[]" type="number" placeholder="Discount Price">
    <input name="stock[]" type="number" placeholder="Stock" required>
  </div>
</div>

<button type="button" onclick="addVariant()">+ Add Variant</button>

<hr>

<button type="submit">Save Product</button>

</form>
</div>

<script>
function addVariant() {
  const container = document.getElementById('variant-container');
  const div = document.createElement('div');
  div.className = 'variant-row';
  div.innerHTML = `
    <input name="variant_name[]" placeholder="Size" required>
    <input name="price[]" type="number" placeholder="Price" required>
    <input name="discount_price[]" type="number" placeholder="Discount">
    <input name="stock[]" type="number" placeholder="Stock" required>
  `;
  container.appendChild(div);
}
</script>

<?php require_once __DIR__ . '/admin_footer.php'; ?>