<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/_common.php';
ensureSessionStarted();

$search = trim($_GET['q'] ?? '');
$where = "";
$params = [];
$types = "";

if ($search !== '') {
  $where = "WHERE p.name LIKE ? OR p.sku LIKE ?";
  $like = "%{$search}%";
  $params = [$like, $like];
  $types = "ss";
}

$sql = "
  SELECT p.*, b.name AS brand_name, c.name AS category_name
  FROM products p
  LEFT JOIN brands b ON p.brand_id = b.id
  LEFT JOIN categories c ON p.category_id = c.id
  $where
  ORDER BY p.created_at DESC
  LIMIT 500
";

$stmt = $mysqli->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();

require_once __DIR__ . '/_layout_top.php';
?>

<div class="card" style="padding:14px">
  <div style="display:flex;gap:10px;justify-content:space-between;flex-wrap:wrap;align-items:center">
    <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <input name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search name / SKU" style="min-width:240px">
      <button class="btn" type="submit">Search</button>
      <?php if ($search !== ''): ?><a class="btn" href="products.php">Reset</a><?php endif; ?>
    </form>
    <a class="btn primary" href="product-add.php">+ Add Product</a>
  </div>
</div>

<div style="height:12px"></div>

<div class="card">
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Name</th>
        <th>Brand</th>
        <th>Category</th>
        <th>Price</th>
        <th>Stock</th>
        <th>Status</th>
        <th>Variants</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while($p = $res->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$p['id'] ?></td>
          <td>
            <?php if (!empty($p['image'])): ?>
              <img class="thumb" src="../../uploads/products/<?= htmlspecialchars($p['image']) ?>" alt="">
            <?php else: ?>
              <div class="thumb" style="display:grid;place-items:center;color:#5a6175">—</div>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-weight:700"><?= htmlspecialchars($p['name']) ?></div>
            <div class="help">SKU: <?= htmlspecialchars($p['sku'] ?? '-') ?></div>
          </td>
          <td><?= htmlspecialchars($p['brand_name'] ?? '-') ?></td>
          <td><?= htmlspecialchars($p['category_name'] ?? '-') ?></td>
          <td>
            <?= number_format((float)$p['base_price'], 2) ?>
            <?php if (!empty($p['sale_price'])): ?>
              <div class="help">Sale: <?= number_format((float)$p['sale_price'],2) ?></div>
            <?php endif; ?>
          </td>
          <td><?= (int)$p['stock'] ?></td>
          <td>
            <?php if ((int)$p['is_active'] === 1): ?>
              <span class="badge on">Active</span>
            <?php else: ?>
              <span class="badge off">Hidden</span>
            <?php endif; ?>
          </td>
          <td><?= ((int)$p['has_variants'] === 1) ? "<span class='badge'>Yes</span>" : "<span class='badge'>No</span>" ?></td>
          <td class="row-actions">
            <a href="product-edit.php?id=<?= (int)$p['id'] ?>">Edit</a>
            <a href="variants.php?product_id=<?= (int)$p['id'] ?>">Variants</a>
            <a class="danger" href="product-delete.php?id=<?= (int)$p['id'] ?>" onclick="return confirm('Delete this product?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
      <?php if ($res->num_rows === 0): ?>
        <tr><td colspan="10" class="help" style="padding:18px">No products found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/_layout_bottom.php'; ?>
