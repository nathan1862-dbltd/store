<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/admin_header.php';

$query = "
    SELECT 
        o.id,
        o.order_number,
        o.full_name,
        o.phone,
        o.address,
        o.status,
        o.payment_method,
        o.payment_status,
        o.subtotal,
        o.shipping,
        o.discount,
        o.total,
        o.created_at,

        oi.product_name,
        oi.variant_name,
        oi.unit_price,
        oi.discount_price,
        oi.quantity,
        oi.line_total

    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    ORDER BY o.created_at DESC
";

$result = $mysqli->query($query);

if (!$result) {
    die("Database error: " . $mysqli->error);
}

$orders = [];

while ($row = $result->fetch_assoc()) {

    $orderId = (int)$row['id'];

    if (!isset($orders[$orderId])) {
        $orders[$orderId] = [
            'id' => $orderId,
            'order_number' => $row['order_number'],
            'full_name' => $row['full_name'],
            'phone' => $row['phone'],
            'address' => $row['address'],
            'status' => $row['status'],
            'payment_method' => $row['payment_method'],
            'payment_status' => $row['payment_status'],
            'subtotal' => (float)$row['subtotal'],
            'discount' => (float)$row['discount'],
            'shipping' => (float)$row['shipping'],
            'total' => (float)$row['total'],
            'created_at' => $row['created_at'],
            'items' => []
        ];
    }

    if (!empty($row['product_name'])) {
        $orders[$orderId]['items'][] = [
            'product_name' => $row['product_name'],
            'variant_name' => $row['variant_name'],
            'price' => (float)$row['price'],
            'discount_price' => (float)$row['discount_price'],
            'quantity' => (int)$row['quantity'],
            'line_total' => (float)$row['line_total']
        ];
    }
}
?>

<style>
.container{max-width:1300px;margin:30px auto}
.card{background:#fff;padding:20px;border-radius:14px;margin-bottom:20px;box-shadow:0 8px 20px rgba(0,0,0,.05)}
.header{display:flex;justify-content:space-between;margin-bottom:10px}
.badge{padding:4px 10px;border-radius:999px;font-size:12px}
.pending{background:#fef3c7;color:#92400e}
.processing{background:#e0f2fe;color:#075985}
.shipped{background:#dcfce7;color:#166534}
.delivered{background:#d1fae5;color:#065f46}
.cancelled{background:#fee2e2;color:#7f1d1d}
small{color:#6b7280}
table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{padding:8px;border-bottom:1px solid #eee;font-size:14px}
button{padding:6px 12px;border:none;border-radius:8px;background:#111827;color:#fff;cursor:pointer}
select{padding:6px;border-radius:8px}
</style>

<div class="container">
<h2>📦 Admin Orders</h2>

<?php if (empty($orders)): ?>
<p>No orders found.</p>
<?php endif; ?>

<?php foreach ($orders as $order): ?>

<div class="card">

  <div class="header">
    <div>
      <strong><?= htmlspecialchars($order['order_number']) ?></strong><br>
      <small>
        <?= htmlspecialchars($order['full_name']) ?> |
        <?= htmlspecialchars($order['phone']) ?>
      </small>
    </div>
    <span class="badge <?= htmlspecialchars($order['status']) ?>">
        <?= ucfirst($order['status']) ?>
    </span>
  </div>

  <small>
    Address: <?= htmlspecialchars($order['address']) ?><br>
    Payment: <?= htmlspecialchars($order['payment_method']) ?> |
    <?= htmlspecialchars($order['payment_status']) ?><br>
    Ordered: <?= htmlspecialchars($order['created_at']) ?>
  </small>

  <table>
    <tr>
      <th>Product</th>
      <th>Variant</th>
      <th>Price</th>
      <th>Discount</th>
      <th>Qty</th>
      <th>Total</th>
    </tr>

    <?php foreach ($order['items'] as $item): ?>
    <tr>
      <td><?= htmlspecialchars($item['product_name']) ?></td>
      <td><?= htmlspecialchars($item['variant_name']) ?></td>
      <td><?= number_format($item['price'], 2) ?></td>
      <td><?= $item['discount_price'] > 0 ? number_format($item['discount_price'], 2) : '-' ?></td>
      <td><?= $item['quantity'] ?></td>
      <td><strong><?= number_format($item['line_total'], 2) ?></strong></td>
    </tr>
    <?php endforeach; ?>
  </table>

  <p style="margin-top:10px">
    Subtotal: <?= number_format($order['subtotal'], 2) ?> |
    Discount: <?= number_format($order['discount'], 2) ?> |
    Shipping: <?= number_format($order['shipping'], 2) ?><br>
    <strong>Final: <?= number_format($order['total'], 2) ?> MMK</strong>
  </p>

  <form method="post" action="order-update.php">
    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
    <select name="status">
      <option value="pending" <?= $order['status']=='pending'?'selected':'' ?>>Pending</option>
      <option value="processing" <?= $order['status']=='processing'?'selected':'' ?>>Processing</option>
      <option value="shipped" <?= $order['status']=='shipped'?'selected':'' ?>>Shipped</option>
      <option value="delivered" <?= $order['status']=='delivered'?'selected':'' ?>>Delivered</option>
      <option value="cancelled" <?= $order['status']=='cancelled'?'selected':'' ?>>Cancelled</option>
    </select>
    <button type="submit">Update</button>
  </form>

</div>

<?php endforeach; ?>

</div>