<?php
require_once __DIR__ . '/adminconfig.php';

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    die("Missing credentials.");
}

$stmt = $mysqli->prepare("
    SELECT id, password_hash, is_admin
    FROM users
    WHERE username = ?
    LIMIT 1
");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {

    if ((int)$user['is_admin'] !== 1) {
        die("Access denied.");
    }

    if (password_verify($password, $user['password_hash'])) {
        $_SESSION[ADMIN_SESSION_KEY] = $user['id'];
        $_SESSION['admin_username'] = $username;

        header("Location: " . ADMIN_DASHBOARD_PAGE);
        exit;
    }
}

die("Invalid login.");
