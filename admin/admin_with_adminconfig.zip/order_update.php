<?php
require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/auth.php';

$orderId = (int)$_POST['order_id'];
$newStatus = $_POST['status'];

$allowed = ['received','shipped','cancelled'];
if (!in_array($newStatus, $allowed)) {
    header('Location: orders.php');
    exit;
}

$stmt = $mysqli->prepare("SELECT status FROM orders WHERE id=?");
$stmt->bind_param('i', $orderId);
$stmt->execute();
$old = $stmt->get_result()->fetch_assoc();
$stmt->close();

$mysqli->begin_transaction();

try {

    $u = $mysqli->prepare("UPDATE orders SET status=? WHERE id=?");
    $u->bind_param('si', $newStatus, $orderId);
    $u->execute();
    $u->close();

    // Restore stock if cancelled
    if ($old['status'] !== 'cancelled' && $newStatus === 'cancelled') {

        $items = $mysqli->prepare("
            SELECT variant_id, quantity
            FROM order_items
            WHERE order_id=?
        ");
        $items->bind_param('i', $orderId);
        $items->execute();
        $res = $items->get_result();

        while($row = $res->fetch_assoc()) {
            $restore = $mysqli->prepare("
                UPDATE product_variants
                SET stock = stock + ?
                WHERE variant_id = ?
            ");
            $restore->bind_param('ii', $row['quantity'], $row['variant_id']);
            $restore->execute();
            $restore->close();
        }

        $items->close();
    }

    $mysqli->commit();

} catch(Exception $e){
    $mysqli->rollback();
}

header('Location: orders.php');
exit;