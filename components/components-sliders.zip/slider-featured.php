<?php
$stmt = $mysqli->prepare("
    SELECT p.id, p.name, p.price, p.discount_price, p.from_price, p.image_path, b.name AS brand_name
    FROM products p
    LEFT JOIN brands b ON b.id = p.brand_id
    WHERE p.stock > 0 AND p.is_featured = 1
    ORDER BY p.created_at DESC
    LIMIT 12
");
$stmt->execute();
$products = $stmt->get_result();

$sliderId = 'featured';
$sliderTitle = 'Featured Products';

include __DIR__ . '/slider-wrapper.php';
