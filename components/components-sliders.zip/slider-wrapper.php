<?php
/**
 * Reusable slider wrapper
 * Expects:
 * - $sliderId
 * - $sliderTitle
 * - $products (mysqli_result)
 */
?>
<section class="section">
  <h2 class="section-title"><?php echo htmlspecialchars($sliderTitle); ?></h2>
  <div class="slider-wrapper">
    <button class="slide-btn prev" onclick="slide('<?php echo $sliderId; ?>', -1)">❮</button>
    <div class="slider" id="<?php echo $sliderId; ?>">
      <?php while ($p = $products->fetch_assoc()): ?>
        <?php include __DIR__ . '/../product-card.php'; ?>
      <?php endwhile; ?>
    </div>
    <button class="slide-btn next" onclick="slide('<?php echo $sliderId; ?>', 1)">❯</button>
  </div>
</section>
