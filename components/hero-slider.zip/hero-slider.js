const track=document.getElementById('heroTrack');
const dotsWrap=document.getElementById('heroDots');
const slides=document.querySelectorAll('.hero-slide');
let index=0;
slides.forEach((_,i)=>{
 const d=document.createElement('span');
 d.onclick=()=>goTo(i);
 dotsWrap.appendChild(d);
});
function goTo(i){
 index=i;
 track.style.transform=`translateX(-${i*100}%)`;
 [...dotsWrap.children].forEach(x=>x.classList.remove('active'));
 dotsWrap.children[i].classList.add('active');
}
setInterval(()=>{index=(index+1)%slides.length;goTo(index)},5000);
goTo(0);
