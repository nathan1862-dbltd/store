document.querySelectorAll('.product-slider').forEach(slider=>{
const track=slider.querySelector('.product-slider-track');
const prev=slider.querySelector('.ps-nav.prev');
const next=slider.querySelector('.ps-nav.next');
const slide=slider.querySelector('.product-slide');
if(!track||!slide)return;
const step=slide.offsetWidth+16;
prev.onclick=()=>track.scrollBy({left:-step*2,behavior:'smooth'});
next.onclick=()=>track.scrollBy({left:step*2,behavior:'smooth'});
});
